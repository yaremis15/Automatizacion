import org.junit.After;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;


import javax.swing.*;
import java.util.concurrent.TimeUnit;


public class PruebaTest {
    private WebDriver firefoxDriver;

    @Test
    public void hacer_una_busqueda() {

        //encontrar el archico .exe del geckoDriver
        System.setProperty("webdriver.gecko.driver", "src/test/resources/drivers/firefox/geckodriver");

        //Creamos opciones sobre nuestro GeckoDriver
        FirefoxOptions options = new FirefoxOptions();

        //estas caracteristicas las cuales se llaman capability
        options.setCapability("marionette", false);

        //Nueva instancia de firefoxDriver
        firefoxDriver = new FirefoxDriver(options);

        //Definimos tiempo de espera hasta que aceptemos un timeout
        firefoxDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        firefoxDriver.manage().window().maximize();

        //Abrimos una URL
        firefoxDriver.get("https://ptec-personal-dev.avaldigitallabs.com/busqueda");

        //Presionamos la tecla ENTER
       // firefoxDriver.findElement(By.xpath("//a[@id='CO']")).sendKeys(Keys.ENTER);

        //Encontrar e interactuar con los elmentos web
        //Ingresar texto en el navegador
        //firefoxDriver.findElement(By.xpath("//input[@id='cb1-edit']")).sendKeys("Monitores");

        //Hacer clic sobre el resultado de la busqueda
        firefoxDriver.findElement(By.xpath("//div[@id='comprar-nueva']")).click();

       //Creamos un elemento Web para poder hacer acciones más avanzadas
        WebElement busqueda = firefoxDriver.findElement(By.xpath("//h2[contains(text(),'Monitor gamer curvo Samsung C32R500 led 32\" dark b')]"));

        System.out.println(busqueda.getText());

        //Verificamos que la cantidad de paises sea el correcto
        Assert.assertTrue(busqueda.getText().contains("C32R500"));
        Assert.assertEquals("Monitor gamer curvo Samsung C32R500 led 32\" dark blue gray 100V/240V", busqueda.getText());
        Assert.assertTrue(busqueda.isDisplayed());

    }
      @After
      public void afterScenario(){
       firefoxDriver.quit();
    }
}
